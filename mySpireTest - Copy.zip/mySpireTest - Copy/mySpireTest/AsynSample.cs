﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace mySpireTest
{
    class AsynSample
    {
        class FileReader
        {
            /// <summary>
            /// 缓存池
            /// </summary>
            private byte[] Buffer { get; set; }
            /// <summary>
            /// 缓存区大小
            /// </summary>
            public int BufferSize { get; set; }

            public FileReader(int bufferSize)
            {
                this.BufferSize = bufferSize;
                this.Buffer = new byte[BufferSize];
            }

            /// <summary>
            /// 同步读取文件
            /// </summary>
            /// <param name="path">文件路径</param>
            public void SynsReadFile(string path)
            {
                Console.WriteLine("同步读取文件 begin");
                using (FileStream fs = new FileStream(path, FileMode.Open))
                {
                    fs.Read(Buffer, 0, BufferSize);
                    string output = System.Text.Encoding.UTF8.GetString(Buffer);
                    Console.WriteLine("读取的文件信息：{0}", output);
                }

                Console.WriteLine("同步读取文件 end");
            }
            /// <summary>
            /// 异步读取文件
            /// </summary>
            /// <param name="path"></param>
            public void AsynReadFile(string path)
            {
                Console.WriteLine("异步读取文件 begin");
                //执行Endread时报错，fs已经释放，注意在异步中不能使用释放需要的资源
                //using (FileStream fs = new FileStream(path, FileMode.Open))
                //{
                //    Buffer = new byte[BufferSize];
                //    fs.BeginRead(Buffer, 0, BufferSize, AsyncReadCallback, fs);
                //} 
                if (File.Exists(path))
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    fs.BeginRead(Buffer, 0, BufferSize, AsyncReadCallback, fs);
                }
                else
                {
                    Console.WriteLine("该文件不存在");
                }

            }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="ar"></param>
            void AsyncReadCallback(IAsyncResult ar)
            {
                FileStream stream = ar.AsyncState as FileStream;
                if (stream != null)
                {
                    Thread.Sleep(1000);
                    //读取结束
                    stream.EndRead(ar);
                    stream.Close();

                    string output = System.Text.Encoding.UTF8.GetString(this.Buffer);
                    Console.WriteLine("读取的文件信息：{0}", output);
                }
            }
        }
        static void testMain(string[] args)
        {
            FileReader reader = new FileReader(1024);

            //改为自己的文件路径
            string path = "C:\\Windows\\DAI.log";

            Console.WriteLine("开始读取文件了...");
            //reader.SynsReadFile(path);

            reader.AsynReadFile(path);

            Console.WriteLine("我这里还有一大滩事呢.");
            DoSomething();
            Console.WriteLine("终于完事了，输入任意键，歇着！");
            Console.ReadKey();
        }
        /// <summary>
        /// 
        /// </summary>
        static void DoSomething()
        {
            Thread.Sleep(1000);
            for (int i = 0; i < 10000; i++)
            {
                if (i % 888 == 0)
                {
                    Console.WriteLine("888的倍数：{0}", i);
                }
            }
        }
    }
}

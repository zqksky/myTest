﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Spire.Xls;
using System.Xml;
using System.IO;
using System.Xml.Linq;
using System.Collections;

using System.Runtime.InteropServices;
using System.Diagnostics;

using System.Management;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;
using System.Threading;
using System.Text.RegularExpressions;


namespace mySpireTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExcelToXml_Click(object sender, EventArgs e)
        {
            //Excel转XML  
            Spire.Xls.Workbook workbook = new Spire.Xls.Workbook();
            workbook.LoadFromFile(@"D:\Qiankun Zheng\zqk\mySpireTest\file\XMLFile\19XF03Y06201_RevD.xls");
            workbook.SaveAsXml(@"D:\Qiankun Zheng\zqk\mySpireTest\\file\XMLFile\result.xml");

            //XML转Excel  
            //Workbook workbook1 = new Workbook();  
            //workbook1.LoadFromXml("result.xml");  
            //workbook1.SaveToFile("test.xlsx",ExcelVersion.Version2010);  

            ExcelToXml(@"D:\Qiankun Zheng\zqk\mySpireTest\file\XMLFile\xmlToExcel.xlsx");
        }
        public XmlDocument ExcelToXml(string strExcelFilePath)
        {
            XmlDocument excelData = new XmlDocument();
            DataSet excelTableDataSet = new DataSet();
            StreamReader excelContent = new StreamReader(strExcelFilePath, System.Text.Encoding.Default);
            string stringConnectToExcelFile = string.Format("provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strExcelFilePath + ";Extended Properties=Excel 12.0;");
            System.Data.OleDb.OleDbConnection oleConnectionToExcelFile = new System.Data.OleDb.OleDbConnection(stringConnectToExcelFile);
            System.Data.OleDb.OleDbDataAdapter oleDataAdapterForGetExcelTable = new System.Data.OleDb.OleDbDataAdapter(string.Format("select * from [Sheet1$]"), oleConnectionToExcelFile);
            try
            {
                oleDataAdapterForGetExcelTable.Fill(excelTableDataSet);
            }
            catch
            {
                return null;
            }
            //string excelOutputXml = Path.GetTempFileName();
            string excelOutputXml = @"D:\Qiankun Zheng\zqk\mySpireTest\file\XMLFile\result2.xml";
            excelTableDataSet.WriteXml(excelOutputXml);
            excelData.Load(excelOutputXml);
            //File.Delete(excelOutputXml);
            return excelData;
        }
        private void btnOpenPath1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "xml文件(*.xml)|;*.xml|所有文件|*.*";
            ofd.ValidateNames = true;
            ofd.CheckPathExists = true;
            ofd.CheckFileExists = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string strFileName = ofd.FileName;
                strFileName = strFileName.Substring(0, strFileName.LastIndexOf('\\') + 1);
                txtPath1.Text = strFileName;
            }
            else
            {
                txtPath1.Text = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test1\";
            }
        }

        private void btnOpenPath2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "xml文件(*.xml)|;*.xml|所有文件|*.*";
            ofd.ValidateNames = true;
            ofd.CheckPathExists = true;
            ofd.CheckFileExists = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string strFileName = ofd.FileName;
                strFileName = strFileName.Substring(0, strFileName.LastIndexOf('\\') + 1);
                txtPath2.Text = strFileName;
            }
            else
            {
                txtPath2.Text = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test2\";
            }
        }
        List<string> strListFileName = new List<string>();
        //List<string> strListFileName2 = new List<string>();

        public delegate void MethodCall(List<string> strList, string strSavePath);//定义个代理 

        private void button2_Click(object sender, EventArgs e)
        {
            //通过匿名委托创建
            //Thread thread = new Thread(delegate() {});

            //通过Lambda表达式创建
            //Thread thread = new Thread(() =>{});

            Thread thread = new Thread(() =>
            {
                bool flagSame = false;
                //List<string> strListFileName = new List<string>();

                //string strPath = @"D:\Qiankun Zheng\zqk\mySpireTest\300_HT_Chiller.XML";
                //string strPath1 = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test1\";
                //string strPath2 = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test2\";
                //string strSavePath = @"D:\Qiankun Zheng\zqk\mySpireTest\file\";

                string strPath1 = txtPath1.Text;
                string strPath2 = txtPath2.Text;
                string strSavePath = strPath1.TrimEnd('\\');
                strSavePath = strSavePath.Substring(0, strSavePath.LastIndexOf('\\') + 1);

                Hashtable ht1 = new Hashtable();
                Hashtable ht2 = new Hashtable();
                List<string> strPathList1 = new List<string>();
                List<string> strPathList2 = new List<string>();

                strPathList1 = getXmlFile(strPath1);
                strPathList2 = getXmlFile(strPath2);
                foreach (var str in strPathList1)
                {
                    if (strPathList2.Contains(str))
                    {
                        ht1 = xmlToHashtable(strPath1 + str);
                        ht2 = xmlToHashtable(strPath2 + str);

                        flagSame = xmlCompare(ht1, ht2, strSavePath + str.Substring(0, str.IndexOf('.')) + ".csv");

                        if (!flagSame)
                        {
                            strListFileName.Add(str.Substring(0, str.IndexOf('.')) + ".csv");
                        }
                    }
                }
                if (File.Exists(strSavePath + "result.xlsx"))
                {
                    //存在
                    //File.Delete(strSavePath + "result.xlsx");
                }
                else
                {
                    //不存在
                }

                saveCsvToExcel(strListFileName, strSavePath + "result.xlsx");

                //MethodCall mc = new MethodCall(saveCsvToExcel);
                //IAsyncResult result = mc.BeginInvoke(strListFileName, strSavePath + "result.xlsx", null, null);
                //mc.EndInvoke(result);//用于接收返回值 
            });
            thread.Start();
        }
        private Hashtable xmlToHashtable(string xmlPath)
        {
            Hashtable ht = new Hashtable();

            XElement xe = XElement.Load(xmlPath);
            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
                                             select ele;
            foreach (var ele in elements)
            {
                string strKey;
                string strValue;

                strKey = ele.Attribute("CHARC").Value;
                strValue = ele.Attribute("VALUE").Value;
                if (ele.LastAttribute.Name == "VALUE_TXT")
                {
                    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                }
                //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);
                ht.Add(strKey, strValue);
            }
            return ht;
        }
        private bool xmlCompare(Hashtable ht1, Hashtable ht2, string SaveFilePath)
        {
            bool flagSame = false;

            List<string> strList1 = new List<string>();
            List<string> strList2 = new List<string>();
            List<string> strList3 = new List<string>();
            //SaveFilePath = @"D:\Qiankun Zheng\zqk\mySpireTest\test.csv";

            foreach (DictionaryEntry de in ht1)
            {
                if (ht2.ContainsKey(de.Key))
                {
                    if (de.Value.ToString() == ht2[de.Key].ToString())
                    {
                        ht2.Remove(de.Key);
                    }
                    else
                    {
                        strList1.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()) + "," + formatStr(ht2[de.Key].ToString()));
                        //strList1.Add(de.Key.ToString() + "," + csvHandlerStr(formatStr(de.Value.ToString())) + "," + csvHandlerStr(formatStr(ht2[de.Key].ToString())));
                        ht2.Remove(de.Key);
                    }
                }
                else
                {
                    strList2.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()));
                    //strList2.Add(de.Key.ToString() + "," + csvHandlerStr(formatStr(de.Value.ToString())));

                }
            }
            foreach (DictionaryEntry de in ht2)
            {
                strList3.Add(de.Key.ToString() + "," + formatStr(de.Value.ToString()));
            }
            if ((strList1.Count + strList2.Count + strList3.Count) > 0)
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);

                //若CSV文件已经打开，先关闭文件
                //closeExcel(str);

                using (FileStream fs = new FileStream(SaveFilePath, FileMode.Create))
                {
                    StreamWriter sw = new StreamWriter(fs, UTF8Encoding.UTF8);
                    //开始写入
                    sw.WriteLine("CHARC,VALUE,VALUE_TEXT,VALUE,VALUE_TEXT");
                    if (strList1.Count > 0)
                    {
                        sw.WriteLine("The data in A and B is not the same");
                        foreach (var s in strList1)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList2.Count > 0)
                    {
                        sw.WriteLine("There is no file1 in file2");
                        foreach (var s in strList2)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    if (strList3.Count > 0)
                    {
                        sw.WriteLine("There is no file2 in file1");
                        foreach (var s in strList3)
                        {
                            sw.WriteLine(s);
                        }
                    }
                    //清空缓冲区
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();
                    //System.Diagnostics.Process.Start(SaveFilePath); //打开此文件
                }
                flagSame = false;
            }
            else
            {
                string str = SaveFilePath.Substring(SaveFilePath.LastIndexOf('\\') + 1);
                str = str.Substring(0, str.LastIndexOf('.'));
                //MessageBox.Show(str + " 结果相同");
                flagSame = true;
            }
            return flagSame;
        }

        private string formatStr(string str)
        {
            string strValue = "";

            string[] strArrayTemp = new string[2];
            strArrayTemp = str.Split(';');
            if (strArrayTemp.Length == 1)
            {
                strValue = strArrayTemp[0] + ",";
            }
            else
            {
                for (int i = 0; i < strArrayTemp.Length; i++)
                {
                    strValue += strArrayTemp[i] + ",";
                }
                strValue = strValue.Trim(',');
            }
            return strValue;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtPath1.Text = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test1\";
            txtPath2.Text = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test2\";
            getXmlFile(@"D:\Qiankun Zheng\zqk\mySpireTest\");
        }

        private List<string> getXmlFile(string path)
        {
            //path = @"D:\Qiankun Zheng\zqk\mySpireTest\";
            List<string> strList = new List<string>();
            DirectoryInfo directory = new DirectoryInfo(path);

            FileInfo[] files = directory.GetFiles("*.xml");

            //输出文件个数 
            //MessageBox.Show(files.Length.ToString()); 

            //遍历文件 
            foreach (FileInfo file in files)
            {
                strList.Add(file.Name);
                //MessageBox.Show(file.Name); 
                //MessageBox.Show(file.Directory.ToString()); 
            }
            return strList;
        }

        public void saveCsvToExcel(List<string> strListFileName, string strSaveFilePath)
        {
            //ExcelOperator myExcel = null;
            ExcelOperator myExcel = new ExcelOperator();

            myExcel.Create();
            //myExcel.Open(@"D:\Qiankun Zheng\zqk\mySpireTest\file\result.xlsx");
            foreach (var str in strListFileName)
            {
                string strTemp = str.Substring(0, str.IndexOf('.'));

                //sheet表名不能超过31个字符
                if (strTemp.Length > 31)
                {
                    strTemp = strTemp.Substring(0, 30);
                }

                myExcel.ImportCSV(@"D:\Qiankun Zheng\zqk\mySpireTest\file\" + str, myExcel.AddSheet(strTemp),
                              (Microsoft.Office.Interop.Excel.Range)((myExcel.GetSheet(strTemp)).get_Range("$A$1")),
                              new int[] { 2, 2, 2, 2, 2 }, true);
            }

            myExcel.SaveAs(strSaveFilePath);
            //myExcel.SaveAs(@"D:\Qiankun Zheng\zqk\mySpireTest\file\result.xlsx");
            myExcel.Close();
        }

        private void closeExcel(List<string> strListFileName)
        {
            foreach (var str in strListFileName)
            {
                //关闭Excel进程
                foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
                {
                    MessageBox.Show(p.MainWindowTitle);
                    if (p.MainWindowTitle == "Microsoft Excel - " + str)
                    {
                        MessageBox.Show(p.MainWindowTitle);
                        p.Kill();//结束进程
                    }
                    //p.Kill();
                }
            }

            //关闭Excel进程
            //foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
            //{
            //MessageBox.Show(p.MainWindowTitle);
            //if (p.MainWindowTitle == "Microsoft Excel - " + strFileName)
            //{
            //    MessageBox.Show(p.MainWindowTitle);
            //    p.Kill();//结束进程
            //}
            //p.Kill();
            //}

            //Process[] pcs = Process.GetProcesses();
            //foreach (Process p in pcs)
            //{
            //    if (p.ProcessName == "EXCEL") //找到名称是notepad的进程
            //    {
            //        if (p.MainWindowTitle == "Microsoft Excel - " + strFileName)
            //        {
            //            MessageBox.Show(p.MainModule.FileName);
            //            p.Kill();//结束进程
            //        }
            //        //p.Kill();//结束进程
            //    }
            //}
        }


        private void testCsvToExcel_Click(object sender, EventArgs e)
        {
            ExcelOperator myExcel = new ExcelOperator();
            myExcel.Create();
            //myExcel.Open(@"D:\Qiankun Zheng\zqk\mySpireTest\file\result.xlsx");

            myExcel.ImportCSV(@"D:\Qiankun Zheng\zqk\mySpireTest\file\300_Chiller.csv", myExcel.AddSheet("test1"),
                              (Microsoft.Office.Interop.Excel.Range)((myExcel.GetSheet("test1")).get_Range("$A$1")),
                              new int[] { 2, 2, 2, 2, 2 }, true);
            myExcel.ImportCSV(@"D:\Qiankun Zheng\zqk\mySpireTest\file\300_Chiller.csv", myExcel.AddSheet("test2"),
                              (Microsoft.Office.Interop.Excel.Range)((myExcel.GetSheet("test2")).get_Range("$A$1")),
                              new int[] { 2, 2, 2, 2, 2 }, true);
            myExcel.SaveAs(@"D:\Qiankun Zheng\zqk\mySpireTest\file\result.xlsx");
            myExcel.Close();
        }

        private void btnTestXml_Click(object sender, EventArgs e)
        {
            //XElement xe = XElement.Load(@"D:\Qiankun Zheng\zqk\mySpireTest\test.XML");
            XElement xe = XElement.Load(@"D:\Qiankun Zheng\zqk\mySpireTest\300_HT_Chiller.XML");
            IEnumerable<XElement> elements = from ele in xe.Elements("RULES").Elements("SAPDATA").Elements("CONFIGURATION").Elements("INST").Elements("CSTICS").Elements("CSTIC")
                                             select ele;
            showInfoByElements(elements);
        }
        private void showInfoByElements(IEnumerable<XElement> elements)
        {
            List<string> strElementList = new List<string>();
            List<string> strAttributeList = new List<string>();
            foreach (var ele in elements)
            {
                //string strElement;
                string strAttribute;
                //strElement = ele.Element("CSTIC").Value;
                strAttribute = ele.Attribute("VALUE").Value;

                //strElementList.Add(strElement);
                //strAttributeList.Add(strAttribute);
                MessageBox.Show("strAttribute=" + strAttribute);
                //MessageBox.Show("Element=" + strElement + "; " + "strAttribute=" + strAttribute);
            }
            //dgvBookInfo.DataSource = modelList;
        }

        [DllImport("kernel32.dll")]
        public static extern IntPtr _lopen(string lpPathName, int iReadWrite);
        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr hObject);
        public const int OF_READWRITE = 2;
        public const int OF_SHARE_DENY_NONE = 0x40;
        public readonly IntPtr HFILE_ERROR = new IntPtr(-1);

        private void btnCloseProcess_Click(object sender, EventArgs e)
        {
            #region 获取系统运行的进程
            //ManagementObjectCollection objects = new ManagementObjectSearcher("SELECT * FROM Win32_Process").Get();
            //foreach (ManagementObject item in objects)
            //{
            //    MessageBox.Show((item["Name"].ToString()));
            //}
            #endregion

            #region 关闭world进程
            //foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcessesByName("WINWORD"))
            //{
            //    p.Kill();
            //}
            #endregion

            //关闭Excel进程
            foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
            {
                //MessageBox.Show(p.MainWindowTitle);
                if (p.MainWindowTitle == "Microsoft Excel - 600_Chiller.csv" || p.MainWindowTitle == "600_Chiller.csv")
                {
                    MessageBox.Show(p.MainWindowTitle);
                    p.Kill();//结束进程
                }
                p.Kill();
            }
            //string appName = Process.GetCurrentProcess().MainModule.FileName;
            //MessageBox.Show(appName);

            #region 关闭TXT进程
            //Process[] pcs = Process.GetProcesses();
            //foreach (Process p in pcs)
            //{
            //    if (p.ProcessName == "notepad") //找到名称是notepad的进程
            //    {
            //        if (p.MainWindowTitle == "路径.txt - Notepad")
            //        {
            //            MessageBox.Show(p.MainModule.FileName);
            //            p.Kill();//结束进程
            //        }

            //        //p.Kill();//结束进程
            //    }
            //}
            #endregion

            #region 判断文件是否被占用
            //string vFileName = @"D:\Qiankun Zheng\zqk\mySpireTest\file\test.txt";
            //if (!File.Exists(vFileName))
            //{
            //    MessageBox.Show("文件都不存在，你就不要拿来耍了");
            //    return;
            //}
            //IntPtr vHandle = _lopen(vFileName, OF_READWRITE | OF_SHARE_DENY_NONE);
            //if (vHandle == HFILE_ERROR)
            //{
            //    MessageBox.Show("文件被占用！");
            //    return;
            //}
            //CloseHandle(vHandle);
            //MessageBox.Show("没有被占用！");
            #endregion

        }

        /** 
        * 方法名称: csvHandlerStr</br> 
        * 方法描述: 处理包含逗号，或者双引号的字段</br> 
        * 方法参数: @param forecastName 
        * 方法参数: @return  </br> 
        * 返回类型: String</br> 
        * 抛出异常:</br> 
        */
        private String csvHandlerStr(String str)
        {
            //csv格式如果有逗号，整体用双引号括起来；如果里面还有双引号就替换成两个双引号，这样导出来的格式就不会有问题了             
            String tempDescription = str;
            //如果有逗号  
            if (str.Contains(","))
            {
                //如果还有双引号，先将双引号转义，避免两边加了双引号后转义错误  
                if (str.Contains("\""))
                {
                    tempDescription = str.Replace("\"", "\"\"");
                }
                //在将逗号转义  
                tempDescription = "\"" + tempDescription + "\"";
            }
            return tempDescription;
        }
        public struct txtDataStruct
        {
           public string strTagName;
           public string strChillerModel;
           public List<string> strListPercentLoad;
           public List<string> strListChillerCapacity;
           public List<string> strListChillerInputkW;
           public List<string> strListChillerEfficiency;
           public List<string> strListChillerCOPR;
        }

        public class txtDataClass
        {
            public string strTagName;
            public string strChillerModel;
            public List<string> strListPercentLoad = new List<string>();
            public List<string> strListChillerCapacity = new List<string>();
            public List<string> strListChillerInputkW = new List<string>();
            public List<string> strListChillerEfficiency = new List<string>();
            public List<string> strListChillerCOPR = new List<string>();
        }
        private List<string> getTxtFile(string filePath,string fileType)
        {
            //path = @"D:\Qiankun Zheng\zqk\mySpireTest\";
            List<string> strList = new List<string>();
            DirectoryInfo directory = new DirectoryInfo(filePath);

            //FileInfo[] files = directory.GetFiles("*.txt");
            FileInfo[] files = directory.GetFiles(fileType);
            //输出文件个数 
            //MessageBox.Show(files.Length.ToString()); 

            //遍历文件 
            foreach (FileInfo file in files)
            {
                strList.Add(file.Name);
                //MessageBox.Show(file.Name); 
                //MessageBox.Show(file.Directory.ToString()); 
            }
            return strList;
        }
        private void btnTestTxt_Click(object sender, EventArgs e)
        {
            #region 读TXT文件
            ////一次将文本内容全部读完，并返回一个包含全部文本内容的字符串
            //string strAllTxt = File.ReadAllText(@"c:\temp\ascii.txt", Encoding.UTF8);

            ////返回一个字符串数组,每一行都是一个数组元素
            //string[] strArrays = File.ReadAllLines(@"c:\temp\ascii.txt", Encoding.ASCII);

            ////当文本的内容比较大时，我们就不要将文本内容一次读完，而应该采用流（Stream）的方式来读取内容
            //StreamReader sr2 = new StreamReader(@"c:\temp\utf-8.txt", Encoding.UTF8);

            //FileStream fs = new FileStream(@"C:\temp\utf-8.txt", FileMode.Open, FileAccess.Read, FileShare.None);

            //StreamReader sr3 = new StreamReader(fs);
            //StreamReader sr4 = new StreamReader(fs, Encoding.UTF8);

            //// OpenText 创建一个UTF-8 编码的StreamReader对象 
            //FileInfo myFile = new FileInfo(@"C:\temp\utf-8.txt");
            //StreamReader sr5 = myFile.OpenText();

            //// OpenText 创建一个UTF-8 编码的StreamReader对象 
            //StreamReader sr6 = File.OpenText(@"C:\temp\utf-8.txt");

            //// 读一行 
            //string nextLine2 = sr2.ReadLine();

            //// 读一个字符 
            //int nextChar = sr3.Read();

            //// 读100个字符 
            //int nChars = 100;
            //char[] charArray = new char[nChars];
            //int nCharsRead = sr4.Read(charArray, 0, nChars);

            //// 全部读完 
            //string restOfStream = sr2.ReadToEnd();

            ////使用完StreamReader之后，不要忘记关闭它： 
            //sr2.Close();
            //sr3.Close();
            //sr4.Close();
            //sr5.Close();
            //sr6.Close();

            //StreamReader sr = File.OpenText(@"C:\temp\ascii.txt");
            //string nextLine;
            //while ((nextLine = sr.ReadLine()) != null)
            //{
            //    MessageBox.Show(nextLine);
            //}
            //sr.Close();

            #endregion

            #region 写TXT文件
            ////写文件和读文件一样，如果你要写入的内容不是很多，可以使用File.WriteAllText方法来一次将内容全部写如文件。如果你要将一个字符串的内容写入文件，可以用File.WriteAllText(FilePath) 或指定编码方式 File.WriteAllText(FilePath, Encoding)方法。

            //string str1 = "Good Morning!"; File.WriteAllText(@"c:\temp\test\ascii.txt", str1);
            //// 也可以指定编码方式 
            //File.WriteAllText(@"c:\temp\test\ascii-2.txt", str1, Encoding.ASCII);

            ////如果你有一个字符串数组，你要将每个字符串元素都写入文件中，可以用File.WriteAllLines方法：
            //string[] strArrays = { "Good Morning!", "Good Afternoon!" }; 
            //File.WriteAllLines(@"c:\temp\ascii.txt", strArrays); 
            //File.WriteAllLines(@"c:\temp\ascii-2.txt", strArrays, Encoding.ASCII);

            ////使用File.WriteAllText或File.WriteAllLines方法时，如果指定的文件路径不存在，会创建一个新文件；如果文件已经存在，则会覆盖原文件。

            ////当要写入的内容比较多时，同样也要使用流（Stream）的方式写入
            //// 如果文件不存在，创建文件； 如果存在，覆盖文件 
            //StreamWriter sw1 = new StreamWriter(@"c:\temp\utf-8.txt");

            //// 也可以指定编码方式，true 是 append text, false 为覆盖原文件 
            //StreamWriter sw2 = new StreamWriter(@"c:\temp\utf-8.txt", true, Encoding.UTF8);

            //// FileMode.CreateNew: 如果文件不存在，创建文件；如果文件已经存在，抛出异常 
            //FileStream fs = new FileStream(@"C:\temp\utf-8.txt", FileMode.CreateNew, FileAccess.Write, FileShare.Read);
            //// UTF-8 为默认编码 
            //StreamWriter sw3 = new StreamWriter(fs);
            //StreamWriter sw4 = new StreamWriter(fs, Encoding.UTF8);

            //// 如果文件不存在，创建文件； 如果存在，覆盖文件 
            //FileInfo myFile = new FileInfo(@"C:\temp\utf-8.txt");
            //StreamWriter sw5 = myFile.CreateText();

            //// 写一个字符            
            //sw1.Write('a');

            //// 写一个字符数组 
            //char[] charArray = new char[100];
            //// initialize these characters 
            //sw2.Write(charArray);

            //// 写一个字符数组的一部分 
            //sw3.Write(charArray, 10, 15);

            ////StreamWriter对象使用完后，不要忘记关闭。
            //sw1.Close();
            //sw2.Close();
            //sw3.Close();
            //sw4.Close();
            //sw5.Close();

            //FileInfo myFile2 = new FileInfo(@"C:\temp\utf-8.txt");
            //StreamWriter sw = myFile.CreateText();

            //string[] strArrays2 = { "早上好", "下午好" };
            //foreach (var s in strArrays2)
            //{
            //    sw.WriteLine(s);
            //}
            //sw.Close();
            #endregion

            #region 测试
            //// 判断文件是否存在，不存在则创建，否则读取值显示到窗体
            //if (!File.Exists(@"D:\Qiankun Zheng\zqk\mySpireTest\file\txtFile\PerfOut1.txt"))
            //{
            //    //FileStream fs1 = new FileStream("F:\\TestTxt.txt", FileMode.Create, FileAccess.Write);//创建写入文件 
            //    //StreamWriter sw = new StreamWriter(fs1);
            //    //sw.WriteLine("写入测试");//开始写入值
            //    //sw.Close();
            //    //fs1.Close();
            //    MessageBox.Show("文件不存在");
            //}
            //else
            //{
            //    string strLineData;
            //    FileStream fs = new FileStream(@"D:\Qiankun Zheng\zqk\mySpireTest\file\txtFile\PerfOut1.txt", FileMode.Open, FileAccess.Read);
            //    StreamReader sr = new StreamReader(fs);
            //    string readLine;
            //    while ((readLine = sr.ReadLine()) != null)
            //    {
            //        if (readLine.IndexOf("Tag Name:") == 0)
            //        {
            //            strLineData = readLine.Substring(readLine.IndexOf(';') + 1);
            //            strLineData = strLineData.Trim();
            //            //MessageBox.Show(strLineData);;
            //        }
            //        if (readLine.IndexOf("Chiller Model") >= 0)
            //        {
            //            strLineData = readLine.Substring(readLine.IndexOf("Model") + 5);
            //            strLineData = strLineData.Trim();
            //            //MessageBox.Show(strLineData);
            //        }
            //        if (readLine.IndexOf("Percent Load") == 0)
            //        {
            //            while ((readLine = sr.ReadLine()) != "")
            //            {
            //                strLineData = readLine.Trim();
            //                //MessageBox.Show(strLineData);
            //            }
            //        }
            //        if (readLine.IndexOf("Chiller Capacity") == 0)
            //        {
            //            while ((readLine = sr.ReadLine()) != "")
            //            {
            //                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
            //                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase); 
            //                strLineData = strLineData.Trim();
            //                //MessageBox.Show(strLineData);
            //            }
            //        }
            //        if (readLine.IndexOf("Chiller Input kW") == 0)
            //        {
            //            while ((readLine = sr.ReadLine()) != "")
            //            {
            //                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
            //                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
            //                strLineData = strLineData.Trim();
            //                //MessageBox.Show(strLineData);
            //            }
            //        }
            //        if (readLine.IndexOf("Chiller Efficiency") == 0)
            //        {
            //            while ((readLine = sr.ReadLine()) != "")
            //            {
            //                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
            //                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
            //                strLineData = strLineData.Replace("/", "");
            //                strLineData = strLineData.Trim();
            //                //MessageBox.Show(strLineData);
            //            }
            //        }
            //        if (readLine.IndexOf("Chiller COPR") == 0)
            //        {
            //            while ((readLine = sr.ReadLine()) != "")
            //            {
            //                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
            //                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
            //                strLineData = strLineData.Replace("/", "");
            //                strLineData = strLineData.Trim();
            //                //MessageBox.Show(strLineData);
            //            }
            //        }
            //    }
            //    sr.Close();
            //    fs.Close();
            //}
            #endregion

            string strTest="";
            Hashtable ht = new Hashtable();
            string strTxtFilePath = @"D:\Qiankun Zheng\zqk\mySpireTest\file\txtFile\PerfOut1.txt";

            ht = GetTxtDataToHashtable(strTxtFilePath);
            txtDataClass txtData = new txtDataClass();
            foreach (DictionaryEntry de in ht)
            {
                txtData = (txtDataClass)de.Value;
                foreach (var str in txtData.strListChillerCapacity)
                {
                    strTest += str + ";";
                }
                strTest = strTest.Trim(';');
                MessageBox.Show(strTest);
            }
        }
        public Hashtable GetTxtDataToHashtable(string strTxtFilePath)
        {
            string strLineData;
            //List<string> strList = new List<string>();
            //txtDataStruct txtData;
            txtDataClass txtData = new txtDataClass();
            Hashtable ht = new Hashtable();

            // 判断文件是否存在，不存在则创建，否则读取值显示到窗体
            if (!File.Exists(strTxtFilePath))
            {
                MessageBox.Show("文件不存在");
            }
            else
            {
                using (FileStream fs = new FileStream(strTxtFilePath, FileMode.Open, FileAccess.Read))
                {
                    StreamReader sr = new StreamReader(fs);
                    string readLine;
                    while ((readLine = sr.ReadLine()) != null)
                    {
                        if (readLine.IndexOf("Tag Name:") == 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf(';') + 1);
                            strLineData = strLineData.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strTagName = strLineData;
                        }
                        if (readLine.IndexOf("Chiller Model") >= 0)
                        {
                            strLineData = readLine.Substring(readLine.IndexOf("Model") + 5);
                            strLineData = strLineData.Trim();
                            //MessageBox.Show(strLineData);
                            txtData.strChillerModel = strLineData;
                        }
                        if (readLine.IndexOf("Percent Load") == 0)
                        {
                            //txtData.strListPercentLoad = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                strLineData = readLine.Trim();
                                //MessageBox.Show(strLineData);
                                txtData.strListPercentLoad.Add(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Capacity") == 0)
                        {
                            //txtData.strListChillerCapacity = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Trim();
                                txtData.strListChillerCapacity.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Input kW") == 0)
                        {
                            //txtData.strListChillerInputkW = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Trim();
                                txtData.strListChillerInputkW.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller Efficiency") == 0)
                        {
                            //txtData.strListChillerEfficiency = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Replace("/", "");
                                strLineData = strLineData.Trim();
                                txtData.strListChillerEfficiency.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                        if (readLine.IndexOf("Chiller COPR") == 0)
                        {
                            //txtData.strListChillerCOPR = new List<string>();
                            while ((readLine = sr.ReadLine()) != "")
                            {
                                //strLineData = Regex.Replace(readLine, @"[^\d]*", "");
                                strLineData = Regex.Replace(readLine, "[a-z]", "", RegexOptions.IgnoreCase);
                                strLineData = strLineData.Replace("/", "");
                                strLineData = strLineData.Trim();
                                txtData.strListChillerCOPR.Add(strLineData);
                                //MessageBox.Show(strLineData);
                            }
                        }
                    }
                    sr.Close();
                    fs.Close();
                }
            }
            ht.Add(txtData.strTagName,txtData);
            return ht;
        }
        private void btnThread_Click(object sender, EventArgs e)
        {
            ThreadOperator myThreadTest = new ThreadOperator();
            myThreadTest.testThread4();
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("test button1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("test button2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //OpenFileDialog openFileDlg = new OpenFileDialog();
            openFileDlg.FileName = "";
            openFileDlg.Filter = "所有文件|*.*";
            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("你选择了文件：" + openFileDlg.FileName);
            }
        }
    }
}

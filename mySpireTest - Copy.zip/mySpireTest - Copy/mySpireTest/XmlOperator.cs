﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml;

namespace mySpireTest
{
    #region 示例XML文件：Product.xml
    //<?xml version="1.0" encoding="utf-8"?>
    //<Products>
    //  <Product>
    //    <ProductID>1</ProductID>
    //    <ProductName>LINQ to XML</ProductName>
    //    <UnitPrice>10</UnitPrice>
    //  </Product>
    //  <Product>
    //    <ProductID>2</ProductID>
    //    <ProductName>LINQ to SQL</ProductName>
    //    <UnitPrice>20</UnitPrice>
    //  </Product>
    //</Products>
    #endregion

    class XmlOperator
    {
        //1.读取XML文件
        //XDocument和XElement类都提供了导入XML文件的Load()方法，可以读取XML文件的内容，并转换为XDocument或XElement类的实例。
        public void xmlLoad()
        {
            XElement root = XElement.Load("Product.xml");
        }

        //2. 查询根元素
        public void xmlRootQuery()
        {
            XDocument doc = XDocument.Load(Environment.CurrentDirectory + @"\Product.xml");

            IEnumerable<XElement> elements = from e in doc.Elements("Products")
                                             select e;
            foreach (XElement e in elements)
            {
                Console.WriteLine("{0}-{1}", e.Name, e.Value);
            }
        }


        //3.  查询节点
        public void xmlNodeQuery()
        {
            XDocument doc = XDocument.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query = from p in doc.Element("Products").Elements("Product")
                        where (int)p.Element("ProductID") == 1
                        select p;

            query.ToList().ForEach(item =>
            {
                Console.WriteLine("{0}-{1}-{2}", item.Element("ProductID").Value, item.Element("ProductName").Value, item.Element("UnitPrice").Value);
            });

            XElement xml = XElement.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query2 = from p in xml.Elements("Product")
                         where (int)p.Element("ProductID") == 1
                         select p;
        }


        //4. 查询子孙节点
        //Descendants轴方法与Elements类型，不过Elements只查找当前元素下的直接子节点，而Descendants则会遍历当前元素下任意层级的子元素。
        public void xmlOffspringNodeQuery()
        {
            XElement root = XElement.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query = from b in root.Descendants("Book")
                        select b;
            foreach (var item in query)
            {
                Console.WriteLine(item.Element("ProductName").Value);
            }
        }

        //5. 查询属性
        public void xmlAttributesQuery()
        {
            XElement xml = XElement.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query = from p in xml.Elements("Product")
                        where (int)p.Attribute("ID") == 1
                        select p;

            XElement xml2 = XElement.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query2 = from p in xml2.Elements("Product")
                         where (int)p.Attribute("ID") == 1
                         select new
                         {
                             ID = p.Attribute("ID").Value,
                             ProductID = p.Element("ProductID").Value,
                             ProductName = p.Element("ProductName").Value
                         };

            XElement xml3 = XElement.Load(Environment.CurrentDirectory + @"\" + "Product.xml");
            var query3 = from p in xml3.Nodes().OfType<XElement>()
                         where (int)p.Attribute("ID") == 1
                         select new
                         {
                             ID = p.Attribute("ID").Value,
                             ProductID = p.Element("ProductID").Value,
                             ProductName = p.Element("ProductName").Value
                         };
        }

        public void Select(string xmlPath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlPath);
            //取根结点
            var root = xmlDoc.DocumentElement;//取到根结点
            //取指定的单个结点
            XmlNode oldChild = xmlDoc.SelectSingleNode("BookStore/NewBook");

            //取指定的结点的集合
            XmlNodeList nodes = xmlDoc.SelectNodes("BookStore/NewBook");

            //取到所有的xml结点
            XmlNodeList nodelist = xmlDoc.GetElementsByTagName("*");
        }
    }
}

﻿namespace mySpireTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExcelToXml = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnTestXml = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPath1 = new System.Windows.Forms.TextBox();
            this.btnOpenPath1 = new System.Windows.Forms.Button();
            this.btnOpenPath2 = new System.Windows.Forms.Button();
            this.txtPath2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCloseProcess = new System.Windows.Forms.Button();
            this.testCsvToExcel = new System.Windows.Forms.Button();
            this.btnTestTxt = new System.Windows.Forms.Button();
            this.btnThread = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExcelToXml
            // 
            this.btnExcelToXml.Location = new System.Drawing.Point(36, 171);
            this.btnExcelToXml.Name = "btnExcelToXml";
            this.btnExcelToXml.Size = new System.Drawing.Size(75, 23);
            this.btnExcelToXml.TabIndex = 0;
            this.btnExcelToXml.Text = "ExcelToXml";
            this.btnExcelToXml.UseVisualStyleBackColor = true;
            this.btnExcelToXml.Click += new System.EventHandler(this.btnExcelToXml_Click);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(198, 119);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 1;
            this.btnTest.Text = "运行";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTestXml
            // 
            this.btnTestXml.Location = new System.Drawing.Point(117, 171);
            this.btnTestXml.Name = "btnTestXml";
            this.btnTestXml.Size = new System.Drawing.Size(75, 23);
            this.btnTestXml.TabIndex = 2;
            this.btnTestXml.Text = "TestXml";
            this.btnTestXml.UseVisualStyleBackColor = true;
            this.btnTestXml.Click += new System.EventHandler(this.btnTestXml_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "XML路径1：";
            // 
            // txtPath1
            // 
            this.txtPath1.Location = new System.Drawing.Point(110, 48);
            this.txtPath1.Name = "txtPath1";
            this.txtPath1.Size = new System.Drawing.Size(256, 20);
            this.txtPath1.TabIndex = 4;
            // 
            // btnOpenPath1
            // 
            this.btnOpenPath1.Location = new System.Drawing.Point(381, 46);
            this.btnOpenPath1.Name = "btnOpenPath1";
            this.btnOpenPath1.Size = new System.Drawing.Size(75, 23);
            this.btnOpenPath1.TabIndex = 5;
            this.btnOpenPath1.Text = "打开";
            this.btnOpenPath1.UseVisualStyleBackColor = true;
            this.btnOpenPath1.Click += new System.EventHandler(this.btnOpenPath1_Click);
            // 
            // btnOpenPath2
            // 
            this.btnOpenPath2.Location = new System.Drawing.Point(381, 82);
            this.btnOpenPath2.Name = "btnOpenPath2";
            this.btnOpenPath2.Size = new System.Drawing.Size(75, 23);
            this.btnOpenPath2.TabIndex = 8;
            this.btnOpenPath2.Text = "打开";
            this.btnOpenPath2.UseVisualStyleBackColor = true;
            this.btnOpenPath2.Click += new System.EventHandler(this.btnOpenPath2_Click);
            // 
            // txtPath2
            // 
            this.txtPath2.Location = new System.Drawing.Point(110, 84);
            this.txtPath2.Name = "txtPath2";
            this.txtPath2.Size = new System.Drawing.Size(256, 20);
            this.txtPath2.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "XML路径2：";
            // 
            // btnCloseProcess
            // 
            this.btnCloseProcess.Location = new System.Drawing.Point(198, 171);
            this.btnCloseProcess.Name = "btnCloseProcess";
            this.btnCloseProcess.Size = new System.Drawing.Size(75, 23);
            this.btnCloseProcess.TabIndex = 9;
            this.btnCloseProcess.Text = "CloseProcess";
            this.btnCloseProcess.UseVisualStyleBackColor = true;
            this.btnCloseProcess.Click += new System.EventHandler(this.btnCloseProcess_Click);
            // 
            // testCsvToExcel
            // 
            this.testCsvToExcel.Location = new System.Drawing.Point(279, 171);
            this.testCsvToExcel.Name = "testCsvToExcel";
            this.testCsvToExcel.Size = new System.Drawing.Size(75, 23);
            this.testCsvToExcel.TabIndex = 10;
            this.testCsvToExcel.Text = "CsvToExcel";
            this.testCsvToExcel.UseVisualStyleBackColor = true;
            this.testCsvToExcel.Click += new System.EventHandler(this.testCsvToExcel_Click);
            // 
            // btnTestTxt
            // 
            this.btnTestTxt.Location = new System.Drawing.Point(360, 171);
            this.btnTestTxt.Name = "btnTestTxt";
            this.btnTestTxt.Size = new System.Drawing.Size(75, 23);
            this.btnTestTxt.TabIndex = 11;
            this.btnTestTxt.Text = "txtOperator";
            this.btnTestTxt.UseVisualStyleBackColor = true;
            this.btnTestTxt.Click += new System.EventHandler(this.btnTestTxt_Click);
            // 
            // btnThread
            // 
            this.btnThread.Location = new System.Drawing.Point(36, 219);
            this.btnThread.Name = "btnThread";
            this.btnThread.Size = new System.Drawing.Size(75, 23);
            this.btnThread.TabIndex = 12;
            this.btnThread.Text = "Thread";
            this.btnThread.UseVisualStyleBackColor = true;
            this.btnThread.Click += new System.EventHandler(this.btnThread_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 314);
            this.Controls.Add(this.btnThread);
            this.Controls.Add(this.btnTestTxt);
            this.Controls.Add(this.testCsvToExcel);
            this.Controls.Add(this.btnCloseProcess);
            this.Controls.Add(this.btnOpenPath2);
            this.Controls.Add(this.txtPath2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnOpenPath1);
            this.Controls.Add(this.txtPath1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTestXml);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnExcelToXml);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExcelToXml;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnTestXml;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPath1;
        private System.Windows.Forms.Button btnOpenPath1;
        private System.Windows.Forms.Button btnOpenPath2;
        private System.Windows.Forms.TextBox txtPath2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCloseProcess;
        private System.Windows.Forms.Button testCsvToExcel;
        private System.Windows.Forms.Button btnTestTxt;
        private System.Windows.Forms.Button btnThread;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.Remoting.Messaging;

namespace mySpireTest
{
    class ThreadOperator
    {
        public void testThread()
        {
            Thread thread = Thread.CurrentThread;
            thread.Name = "btnThread";
            string threadMessage = string.Format("Thread ID:{0}\n    Current AppDomainId:{1}\n    " +
                "Current ContextId:{2}\n    Thread Name:{3}\n    " +
                "Thread State:{4}\n    Thread Priority:{5}\n",
                thread.ManagedThreadId, Thread.GetDomainID(), Thread.CurrentContext.ContextID,
                thread.Name, thread.ThreadState, thread.Priority);
            MessageBox.Show(threadMessage);
        }
        public void ShowMessage()
        {
            string message = string.Format("Async threadId is :{0}",
                                            Thread.CurrentThread.ManagedThreadId);
            MessageBox.Show(message);

            for (int n = 0; n < 10; n++)
            {
                Thread.Sleep(300);
                MessageBox.Show("The number is:" + n.ToString());
            }
        }
        public void testThread2()
        {
            Thread thread = new Thread(new ThreadStart(ShowMessage));
            thread.Start();
            MessageBox.Show("Do something ..........!");
            MessageBox.Show("Main thread working is complete!");
        }
        public class Person
        {
            public string Name
            {
                get;
                set;
            }
            public int Age
            {
                get;
                set;
            }
        }

        public void ShowMessage(object person)
        {
            if (person != null)
            {
                Person _person = (Person)person;
                string message = string.Format("\n{0}'s age is {1}!\nAsync threadId is:{2}",
                    _person.Name, _person.Age, Thread.CurrentThread.ManagedThreadId);
                Console.WriteLine(message);
            }
            for (int n = 0; n < 2; n++)
            {
                Thread.Sleep(300);
                MessageBox.Show("The number is:" + n.ToString());
            }
        }

        public void testThread3()
        {
            MessageBox.Show("Main threadId is:" + Thread.CurrentThread.ManagedThreadId);

            //绑定带参数的异步方法
            Thread thread = new Thread(new ParameterizedThreadStart(ShowMessage));
            Person person = new Person();
            person.Name = "Jack";
            person.Age = 21;
            thread.Start(person);  //启动异步线程 

            MessageBox.Show("Do something ..........!");
            MessageBox.Show("Main thread working is complete!");

        }

        //delegate void MyDelegate1();

        //public void testThread4()
        //{
        //    MyDelegate1 delegate1 = new MyDelegate(AsyncThread);
        //    //显示委托类的几个方法成员     
        //    var methods = delegate1.GetType().GetMethods();
        //    if (methods != null)
        //        foreach (MethodInfo info in methods)
        //            Console.WriteLine(info.Name);
        //    Console.ReadKey();
        //}
        //public class MyDelegate1 : MulticastDelegate
        //{
        //    public MyDelegate1(object target, int methodPtr);
        //    //调用委托方法
        //    public virtual void Invoke();
        //    //异步委托
        //    public virtual IAsyncResult BeginInvoke(AsyncCallback callback, object state);
        //    public virtual void EndInvoke(IAsyncResult result);
        //}

        #region IAsyncResult接口
        //public interface IAsyncResult
        //{
        //    object AsyncState { get; }            //获取用户定义的对象，它限定或包含关于异步操作的信息。
        //    WailHandle AsyncWaitHandle { get; }   //获取用于等待异步操作完成的 WaitHandle。
        //    bool CompletedSynchronously { get; }  //获取异步操作是否同步完成的指示。
        //    bool IsCompleted { get; }             //获取异步操作是否已完成的指示。
        //}
        #endregion

        delegate string MyDelegate(string name);

        public void testThread4()
        {
            ThreadMessage("Main Thread");

            //建立委托
            MyDelegate myDelegate = new MyDelegate(Hello);
            //异步调用委托，获取计算结果
            IAsyncResult result = myDelegate.BeginInvoke("Leslie", null, null);

            //在异步线程未完成前执行其他工作
            while (!result.IsCompleted)
            {
                Thread.Sleep(200);      //虚拟操作
                MessageBox.Show("Main thead do work!");
            }
            //在异步线程未完成前执行其他工作
            //while (!result.AsyncWaitHandle.WaitOne(200))
            //{
            //    MessageBox.Show("Main thead do work!");
            //}

            string data = myDelegate.EndInvoke(result);
            MessageBox.Show(data);

            //Console.ReadKey();
        }

        static string Hello(string name)
        {
            ThreadMessage("Async Thread");
            Thread.Sleep(2000);
            return "Hello " + name;
        }

        static void ThreadMessage(string data)
        {
            string message = string.Format("{0}\n  ThreadId is:{1}",
                   data, Thread.CurrentThread.ManagedThreadId);
            MessageBox.Show(message);
        }

        public void testThread5()
        {
            ThreadMessage("Main Thread");

            //建立委托
            MyDelegate myDelegate = new MyDelegate(Hello);

            //异步调用委托，获取计算结果
            myDelegate.BeginInvoke("Leslie", new AsyncCallback(Completed), null);

            //在启动异步线程后，主线程可以继续工作而不需要等待
            for (int n = 0; n < 6; n++)
            {
                MessageBox.Show("  Main thread do work!");
            }
        }
        static void Completed(IAsyncResult result)
        {
            ThreadMessage("Async Completed");

            //获取委托对象，调用EndInvoke方法获取运行结果
            AsyncResult _result = (AsyncResult)result;
            MyDelegate myDelegate = (MyDelegate)_result.AsyncDelegate;
            string data = myDelegate.EndInvoke(_result);
            MessageBox.Show(data);
        }
    }
}
